# workshop-java-v3

## Requirements
* Java 8
* Maven

## Run

```
mvn spring-boot:run

```
